<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */

// Route::get('/', function () {
//     return view('admin.dashboard');
// });

Route::get('/', function () {
    return view('welcome');
});
Route::group(['middleware' => 'auth'], function () {
//    Route::resource('users', 'UsersController');
    //users master
    Route::get('/users/', 'UsersController@index');
    Route::post('/user_register/', 'UsersController@store')->name('user_register');
    Route::post('/user_edit/', 'UsersController@edit')->name('user_edit');
    Route::get('/user_delete/{id}', 'UsersController@destroy')->name('user_delete');

    // classes Masters    
    Route::get('/cls/', 'ClassController@index');
    Route::post('/class_create/', 'ClassController@store')->name('class_create');
    Route::post('/class_edit/', 'ClassController@edit')->name('class_edit');
    Route::get('/class_delete/{id}', 'ClassController@destroy')->name('class_delete');

    // section Masters
    Route::get('/section/', 'SectionController@index');
    Route::post('/section_create/', 'SectionController@store')->name('section_create');
    Route::post('/section_edit/', 'SectionController@edit')->name('section_edit');
    Route::get('/section_delete/{id}', 'SectionController@destroy')->name('section_delete');

    // Class & section mapping
    Route::get('/csmap/', 'CsController@index');
    Route::post('/cs_create/', 'CsController@store')->name('cs_create');
    Route::get('/cs_delete/{id}', 'CsController@destroy')->name('cs_delete');

    // student creation
    Route::get('/student/', 'StudentController@index');
    Route::post('/fetch_section/', 'StudentController@show')->name('fetch_section');
    Route::post('/student_register/', 'StudentController@store')->name('student_register');
    Route::post('/edit_student/', 'StudentController@edit')->name('edit_student');
    Route::get('/delete_student/{id}', 'StudentController@destroy')->name('delete_student');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
