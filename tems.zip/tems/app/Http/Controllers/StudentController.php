<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Hash;
use Illuminate\Foundation\Auth\RegistersUsers;
use App\ClassMst;
use App\Section;
use App\Cs;
use App\Student;
use DB;
use Session;

class StudentController extends Controller {

    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $this->data['class'] = ClassMst::all();
        $this->data['section'] = Section::all();
        $this->data['student'] = DB::table('students')
                ->leftjoin('class_msts', 'class_msts.id', '=', 'std_class')
                ->leftjoin('sections', 'sections.id', '=', 'std_section')
                ->get();

        return view('admin/student', $this->data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(array $data) {
        if (empty($data['hid'])) {
            return Student::create([
                        'std_name' => $data['name'],
                        'std_class' => $data['class'],
                        'std_section' => $data['section'],
                        'std_rollno' => $data['rollno'],
                        'std_father' => $data['fname'],
                        'std_mother' => $data['mname'],
                        'std_mobile' => $data['mobile'],
                        'std_address' => $data['address'],
                        'created_by' => auth()->id(),
            ]);
        } else {
            return DB::table('students')->where('id', '=', $data['hid'])
                            ->update([
                                'std_name' => $data['name'],
                                'std_class' => $data['class'],
                                'std_section' => $data['section'],
                                'std_rollno' => $data['rollno'],
                                'std_father' => $data['fname'],
                                'std_mother' => $data['mname'],
                                'std_mobile' => $data['mobile'],
                                'std_address' => $data['address'],
                                'created_by' => auth()->id(),
            ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {
        $this->validator($request->all())->validate();
        event(new Registered($user = $this->create($request->all())));
        return redirect('/student');
    }

    protected function validator(array $data) {
        return Validator::make($data, [
                    'name' => ['required', 'string'],
                    'class' => ['required'],
                    'section' => ['required'],
                    'rollno' => ['required'],
                    'fname' => ['required'],
                    'mname' => ['required'],
                    'mobile' => ['required', 'numeric'],
                    'address' => ['required'],
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request) {
        $id = $request->id;
//        $data = DB::table('users')->where('id', '=', $id)->first();
        $data = DB::table('cs')
                ->leftjoin('class_msts', 'class_msts.id', '=', 'cs.class_id')
                ->leftjoin('sections', 'sections.id', '=', 'section_id')
                ->where('class_msts.id', '=', $id)
                ->get();

        return response()->json($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request) {
        $id = $request->id;
        $data = DB::table('students')
                ->leftjoin('class_msts', 'class_msts.id', '=', 'std_class')
                ->leftjoin('sections', 'sections.id', '=', 'std_section')
                ->get()
                ->where('id', '=', $id);
        return response()->json($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id) {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id) {
        $delete = DB::table('students')->where('id', '=', $id)->delete();
        return redirect('/student')
                        ->with('success', 'Student has been deleted successfully!');
    }

}
