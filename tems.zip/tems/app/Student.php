<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model {

    protected $table = "students";
    protected $fillable = ['std_name','std_class','std_section','std_rollno','std_father','std_mother','std_mobile','std_address', 'created_by'];
    public $timestamps = true;
    

}
