<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cs extends Model {

    protected $table = "cs";
    protected $fillable = ['class_id', 'section_id', 'created_by'];
    public $timestamps = true;

    public function class_msts() {
        return $this->belongsToMany('App\ClassMst', 'App\Section');
    }
     

}
