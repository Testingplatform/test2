<?php $__env->startSection('content'); ?>

<!--=================================
wrapper -->

<div class="content-wrapper">
    <div class="page-title">
        <div class="row">
            <div class="col-sm-6">
                <h4 class="mb-0"> Users Master</h4>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
                    <li class="breadcrumb-item"><a href="index.html" class="default-color">Home</a></li>
                    <li class="breadcrumb-item active">User Master</li>
                </ol>
            </div>
        </div>
    </div>
    <!-- widgets -->
    <div class="row">


        <div class="col-xl-12 mb-30">

            <div class="card card-statistics mb-30">
                <div class="card-body">
                    <h5 class="card-title">User form</h5>
                    <form method="POST" action="<?php echo e(route('student_register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class=" form-row">
                            <input type="hidden" name="hid" id="hid">
                            <div class=" col-md-3 form-group">
                                <label for="name">Student Name</label>
                                <input type="text" value="<?php echo e(old('name')); ?>" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" aria-describedby="nameHelp" placeholder="Enter Name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="class">Classes</label>
                                <select class="custom-select mr-sm-2 <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" onchange="get_sections(this.value);" id="class" name="class" >
                                    <option value="">--Select Class--</option>
                                    <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   

                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->class_name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="section">Sections</label>
                                <select class="custom-select mr-sm-2 <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="section" name="section">
                                    <option value="">--Select Section--</option>
                                    <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   

                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->section_name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class=" col-md-3 form-group">
                                <label for="rollno">Roll no</label>
                                <input type="rollno" value="<?php echo e(old('rollno')); ?>" class="form-control <?php $__errorArgs = ['rollno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="rollno" name="rollno" aria-describedby="emailHelp" placeholder="Enter Roll no">
                                <?php $__errorArgs = ['rollno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="fname">Father Name</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="fname" name="fname"  placeholder="Father Name">
                                <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="mname">Mother Name</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['mname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="mname" name="mname"  placeholder="Mother Name">
                                <?php $__errorArgs = ['mname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="mobile">Mobile No</label>
                                <input type="number" class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="mobile" name="mobile"  placeholder="Mobile">
                                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="address">Address</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="address" name="address"  placeholder="Address">
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                        <?php if(session('success')): ?>
                        <div class="alert alert-secondary alert-dismissible fade show" role="alert">
                            <strong> <?php echo e(session('success')); ?></strong>  
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>

                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">


        <div class="col-xl-12 mb-30">     
            <div class="card card-statistics h-100"> 
                <div class="card-body">
                    <div class="d-block d-md-flex justify-content-between">
                        <div class="d-block">
                            <h5 class="card-title pb-0 border-0">Student List</h5>
                        </div>

                    </div>
                    <div class="table-responsive mt-15">
                        <table class="table center-aligned-table mb-0">
                            <thead>
                                <tr class="text-dark">
                                    <th>Name</th>
                                    <th>Class</th>
                                    <th>Section</th>                   
                                    <th>Roll No</th>                     
                                    <th>Father</th>
                                    <th>Mother</th>
                                    <th>Mobile</th>
                                    <th>Address</th>
                                    <th></th>
                                    <th></th>


                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                <tr>
                                    <td><?php echo e($row->std_name); ?></td>
                                    <td><?php echo e($row->class_name); ?></td>
                                    <td><?php echo e($row->section_name); ?></td>
                                    <td><?php echo e($row->std_rollno); ?></td>
                                    <td><?php echo e($row->std_father); ?></td>
                                    <td><?php echo e($row->std_mother); ?></td>
                                    <td><?php echo e($row->std_mobile); ?></td>
                                    <td><?php echo e($row->std_address); ?></td>

                                    <td><span onclick="edit_student('<?php echo e($row->id); ?>')" class="btn btn-outline-success btn-sm">EDIT</span></td>
                                    <td><span onclick="delete_student('<?php echo e($row->id); ?>')"  class="btn btn-outline-danger btn-sm">Delete</span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php echo e(csrf_field()); ?>

                            </tbody>

                        </table>

                    </div>
                </div>
            </div>   
        </div>


    </div>
    <!--=================================
     wrapper -->
    <script>
        function get_sections(id) {

        var _token = $('input[name="_token"]').val();
        $.ajax({
        type: 'POST',
                url: '<?php echo e(route('fetch_section')); ?>',
                data: {id: id, _token: _token},
                dataType: 'json',
                success: function (response) {
                $('#section').empty();
                $('#section').append('<option value="">--Select Section--</option>');
                $.each(response, function (index, data) {
                $('#section').append('<option value="' + data['id'] + '">' + data['section_name'] + '</option>');
                });
                }
        });
        }

        function delete_student(id){

        var r = confirm("Are you Sure want to delete User?");
        if (r == true) {
        window.location.href = "/delete_student/" + id;
        }
        }
        function edit_student(id){
        var _token = $('input[name="_token"]').val();
        $.ajax({
        type: 'POST',
                url: '<?php echo e(route('edit_student')); ?>',
                data: {id: id, _token:_token},
                dataType: 'json',
                success: function (response) {
                $.each(response, function (index, data) {
               
                $('input[name="hid"]').val(data['id']);
                $('input[name="name"]').val(data['std_name']);
                $('input[name="rollno"]').val(data['std_rollno']);
                $('input[name="fname"]').val(data['std_father']);
                $('input[name="mname"]').val(data['std_mother']);
                $('input[name="mobile"]').val(data['std_mobile']);
                $('input[name="address"]').val(data['std_address']);
                $('#class').val(data['std_class']).change();
                $('#section').val(data['std_section']);
                });
                }


        });
        }
    </script>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tems\resources\views/admin/student.blade.php ENDPATH**/ ?>