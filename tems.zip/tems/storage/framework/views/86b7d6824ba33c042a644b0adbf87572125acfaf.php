<?php $__env->startSection('content'); ?>

<!--=================================
wrapper -->

<div class="content-wrapper">
    <div class="page-title">
        <div class="row">
            <div class="col-sm-6">
                <h4 class="mb-0"> Class & Section Mapping</h4>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
                    <li class="breadcrumb-item"><a href="/home" class="default-color">Home</a></li>
                    <li class="breadcrumb-item active"> Class & Section Mapping</li>
                </ol>
            </div>
        </div>
    </div>
    <!-- widgets -->
    <div class="row">


        <div class="col-xl-12 mb-30">

            <div class="card card-statistics mb-30">
                <div class="card-body">
                    <h5 class="card-title">Class & Section Mapping form</h5>
                    <form method="POST" action="<?php echo e(route('cs_create')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class=" form-row">
                            <input type="hidden" name="hid" id="hid">
                            <div class="col-md-3 form-group">
                                <label for="class">Classes</label>
                                <select class="custom-select mr-sm-2 <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="class" name="class">
                                    <option value="">--Select Class--</option>
                                    <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   

                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->class_name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="section">Sections</label>
                                <select class="custom-select mr-sm-2 <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="section" name="section">
                                    <option value="">--Select Section--</option>
                                    <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   

                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->section_name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['section'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                        <?php if(session('success')): ?>
                        <div class="alert alert-secondary alert-dismissible fade show" role="alert">
                            <strong> <?php echo e(session('success')); ?></strong>  
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                         
                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">

        <div class="col-xl-12 mb-30">     
            <div class="card card-statistics h-100"> 
                <div class="card-body">
                    <div class="d-block d-md-flex justify-content-between">
                        <div class="d-block">
                            <h5 class="card-title pb-0 border-0">Class & Section List</h5>
                        </div>

                    </div>
                    <div class="table-responsive mt-15">
                        <table class="table center-aligned-table mb-0">
                            <thead>
                                <tr class="text-dark">
                                    <th>Class</th>
                                    <th>Section</th> 
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $map; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                <tr>
                                    <td><?php echo e($row->class_name); ?></td>
                                    <td><?php echo e($row->section_name); ?></td> 
                                    <td><span onclick="delete_cs('<?php echo e($row->id); ?>')"  class="btn btn-outline-danger btn-sm">Delete</span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php echo e(csrf_field()); ?>

                            </tbody>

                        </table>

                    </div>
                </div>
            </div>   
        </div>
    </div>
    <!--=================================
     wrapper -->
    <script>
     function delete_cs(id){

        var r = confirm("Are you Sure want to delete User?");
        if (r == true) {
        window.location.href = "/cs_delete/" + id;
        }
        }
    
    </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tems\resources\views/admin/cs.blade.php ENDPATH**/ ?>