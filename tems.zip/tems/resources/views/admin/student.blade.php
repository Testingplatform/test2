@extends('layout.master')

@section('content')

<!--=================================
wrapper -->

<div class="content-wrapper">
    <div class="page-title">
        <div class="row">
            <div class="col-sm-6">
                <h4 class="mb-0"> Users Master</h4>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
                    <li class="breadcrumb-item"><a href="index.html" class="default-color">Home</a></li>
                    <li class="breadcrumb-item active">User Master</li>
                </ol>
            </div>
        </div>
    </div>
    <!-- widgets -->
    <div class="row">


        <div class="col-xl-12 mb-30">

            <div class="card card-statistics mb-30">
                <div class="card-body">
                    <h5 class="card-title">User form</h5>
                    <form method="POST" action="{{ route('student_register') }}">
                        @csrf
                        <div class=" form-row">
                            <input type="hidden" name="hid" id="hid">
                            <div class=" col-md-3 form-group">
                                <label for="name">Student Name</label>
                                <input type="text" value="{{ old('name') }}" class="form-control  @error('name') is-invalid @enderror" id="name" name="name" aria-describedby="nameHelp" placeholder="Enter Name">
                                @error('name')
                                <span class="invalid-feedback text-red" role="alert">
                                    {{ $message }} 
                                </span>
                                @enderror
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="class">Classes</label>
                                <select class="custom-select mr-sm-2 @error('class') is-invalid @enderror" onchange="get_sections(this.value);" id="class" name="class" >
                                    <option value="">--Select Class--</option>
                                    @foreach($class as $row)   

                                    <option value="{{ $row->id }}">{{ $row->class_name }}</option>

                                    @endforeach
                                </select>
                                @error('class')
                                <span class="invalid-feedback text-red" role="alert">
                                    {{ $message }} 
                                </span>
                                @enderror
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="section">Sections</label>
                                <select class="custom-select mr-sm-2 @error('section') is-invalid @enderror" id="section" name="section">
                                    <option value="">--Select Section--</option>
                                    @foreach($section as $row)   

                                    <option value="{{ $row->id }}">{{ $row->section_name }}</option>

                                    @endforeach
                                </select>
                                @error('section')
                                <span class="invalid-feedback text-red" role="alert">
                                    {{ $message }} 
                                </span>
                                @enderror
                            </div>
                            <div class=" col-md-3 form-group">
                                <label for="rollno">Roll no</label>
                                <input type="rollno" value="{{ old('rollno') }}" class="form-control @error('rollno') is-invalid @enderror" id="rollno" name="rollno" aria-describedby="emailHelp" placeholder="Enter Roll no">
                                @error('rollno')
                                <span class="invalid-feedback text-red" role="alert">
                                    {{ $message }} 
                                </span>
                                @enderror
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="fname">Father Name</label>
                                <input type="text" class="form-control @error('fname') is-invalid @enderror" id="fname" name="fname"  placeholder="Father Name">
                                @error('fname')
                                <span class="invalid-feedback text-red" role="alert">
                                    {{ $message }} 
                                </span>
                                @enderror
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="mname">Mother Name</label>
                                <input type="text" class="form-control @error('mname') is-invalid @enderror" id="mname" name="mname"  placeholder="Mother Name">
                                @error('mname')
                                <span class="invalid-feedback text-red" role="alert">
                                    {{ $message }} 
                                </span>
                                @enderror
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="mobile">Mobile No</label>
                                <input type="number" class="form-control @error('mobile') is-invalid @enderror" id="mobile" name="mobile"  placeholder="Mobile">
                                @error('mobile')
                                <span class="invalid-feedback text-red" role="alert">
                                    {{ $message }} 
                                </span>
                                @enderror
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="address">Address</label>
                                <input type="text" class="form-control @error('address') is-invalid @enderror" id="address" name="address"  placeholder="Address">
                                @error('address')
                                <span class="invalid-feedback text-red" role="alert">
                                    {{ $message }} 
                                </span>
                                @enderror
                            </div>

                        </div>
                        @if(session('success'))
                        <div class="alert alert-secondary alert-dismissible fade show" role="alert">
                            <strong> {{session('success')}}</strong>  
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>

                        @endif
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">


        <div class="col-xl-12 mb-30">     
            <div class="card card-statistics h-100"> 
                <div class="card-body">
                    <div class="d-block d-md-flex justify-content-between">
                        <div class="d-block">
                            <h5 class="card-title pb-0 border-0">Student List</h5>
                        </div>

                    </div>
                    <div class="table-responsive mt-15">
                        <table class="table center-aligned-table mb-0">
                            <thead>
                                <tr class="text-dark">
                                    <th>Name</th>
                                    <th>Class</th>
                                    <th>Section</th>                   
                                    <th>Roll No</th>                     
                                    <th>Father</th>
                                    <th>Mother</th>
                                    <th>Mobile</th>
                                    <th>Address</th>
                                    <th></th>
                                    <th></th>


                                </tr>
                            </thead>
                            <tbody>
                                @foreach($student as $row)   
                                <tr>
                                    <td>{{ $row->std_name }}</td>
                                    <td>{{ $row->class_name }}</td>
                                    <td>{{ $row->section_name }}</td>
                                    <td>{{ $row->std_rollno }}</td>
                                    <td>{{ $row->std_father }}</td>
                                    <td>{{ $row->std_mother }}</td>
                                    <td>{{ $row->std_mobile }}</td>
                                    <td>{{ $row->std_address }}</td>

                                    <td><span onclick="edit_student('{{$row->id }}')" class="btn btn-outline-success btn-sm">EDIT</span></td>
                                    <td><span onclick="delete_student('{{$row->id }}')"  class="btn btn-outline-danger btn-sm">Delete</span></td>
                                </tr>
                                @endforeach

                                {{ csrf_field() }}
                            </tbody>

                        </table>

                    </div>
                </div>
            </div>   
        </div>


    </div>
    <!--=================================
     wrapper -->
    <script>
        function get_sections(id) {

        var _token = $('input[name="_token"]').val();
        $.ajax({
        type: 'POST',
                url: '{{ route('fetch_section') }}',
                data: {id: id, _token: _token},
                dataType: 'json',
                success: function (response) {
                $('#section').empty();
                $('#section').append('<option value="">--Select Section--</option>');
                $.each(response, function (index, data) {
                $('#section').append('<option value="' + data['id'] + '">' + data['section_name'] + '</option>');
                });
                }
        });
        }

        function delete_student(id){

        var r = confirm("Are you Sure want to delete User?");
        if (r == true) {
        window.location.href = "/delete_student/" + id;
        }
        }
        function edit_student(id){
        var _token = $('input[name="_token"]').val();
        $.ajax({
        type: 'POST',
                url: '{{ route('edit_student') }}',
                data: {id: id, _token:_token},
                dataType: 'json',
                success: function (response) {
                $.each(response, function (index, data) {
               
                $('input[name="hid"]').val(data['id']);
                $('input[name="name"]').val(data['std_name']);
                $('input[name="rollno"]').val(data['std_rollno']);
                $('input[name="fname"]').val(data['std_father']);
                $('input[name="mname"]').val(data['std_mother']);
                $('input[name="mobile"]').val(data['std_mobile']);
                $('input[name="address"]').val(data['std_address']);
                $('#class').val(data['std_class']).change();
                $('#section').val(data['std_section']);
                });
                }


        });
        }
    </script>


    @endsection
