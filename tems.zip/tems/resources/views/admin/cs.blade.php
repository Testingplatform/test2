@extends('layout.master')

@section('content')

<!--=================================
wrapper -->

<div class="content-wrapper">
    <div class="page-title">
        <div class="row">
            <div class="col-sm-6">
                <h4 class="mb-0"> Class & Section Mapping</h4>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
                    <li class="breadcrumb-item"><a href="/home" class="default-color">Home</a></li>
                    <li class="breadcrumb-item active"> Class & Section Mapping</li>
                </ol>
            </div>
        </div>
    </div>
    <!-- widgets -->
    <div class="row">


        <div class="col-xl-12 mb-30">

            <div class="card card-statistics mb-30">
                <div class="card-body">
                    <h5 class="card-title">Class & Section Mapping form</h5>
                    <form method="POST" action="{{ route('cs_create') }}">
                        @csrf
                        <div class=" form-row">
                            <input type="hidden" name="hid" id="hid">
                            <div class="col-md-3 form-group">
                                <label for="class">Classes</label>
                                <select class="custom-select mr-sm-2 @error('class') is-invalid @enderror" id="class" name="class">
                                    <option value="">--Select Class--</option>
                                    @foreach($class as $row)   

                                    <option value="{{ $row->id }}">{{ $row->class_name }}</option>

                                    @endforeach
                                </select>
                                @error('class')
                                <span class="invalid-feedback text-red" role="alert">
                                    {{ $message }} 
                                </span>
                                @enderror
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="section">Sections</label>
                                <select class="custom-select mr-sm-2 @error('section') is-invalid @enderror" id="section" name="section">
                                    <option value="">--Select Section--</option>
                                    @foreach($section as $row)   

                                    <option value="{{ $row->id }}">{{ $row->section_name }}</option>

                                    @endforeach
                                </select>
                                @error('section')
                                <span class="invalid-feedback text-red" role="alert">
                                    {{ $message }} 
                                </span>
                                @enderror
                            </div>

                        </div>
                        @if(session('success'))
                        <div class="alert alert-secondary alert-dismissible fade show" role="alert">
                            <strong> {{session('success')}}</strong>  
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                         
                        @endif
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">

        <div class="col-xl-12 mb-30">     
            <div class="card card-statistics h-100"> 
                <div class="card-body">
                    <div class="d-block d-md-flex justify-content-between">
                        <div class="d-block">
                            <h5 class="card-title pb-0 border-0">Class & Section List</h5>
                        </div>

                    </div>
                    <div class="table-responsive mt-15">
                        <table class="table center-aligned-table mb-0">
                            <thead>
                                <tr class="text-dark">
                                    <th>Class</th>
                                    <th>Section</th> 
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($map as $row)  
                                <tr>
                                    <td>{{ $row->class_name }}</td>
                                    <td>{{ $row->section_name }}</td> 
                                    <td><span onclick="delete_cs('{{$row->id }}')"  class="btn btn-outline-danger btn-sm">Delete</span></td>
                                </tr>
                                @endforeach

                                {{ csrf_field() }}
                            </tbody>

                        </table>

                    </div>
                </div>
            </div>   
        </div>
    </div>
    <!--=================================
     wrapper -->
    <script>
     function delete_cs(id){

        var r = confirm("Are you Sure want to delete User?");
        if (r == true) {
        window.location.href = "/cs_delete/" + id;
        }
        }
    
    </script>

    @endsection
